<template>
  <div class="home">
    <ly-tab
      v-model="selectedId"
      :items="items"
      :options="options"
      @change="handleChange"
      class="fix"
    />
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "Home",
  data() {
    return {
      selectedId: 0, //选中的id
      items: [
        { label: "热门" },
        { label: "服饰" },
        { label: "鞋包" },
        { label: "食品" },
        { label: "内衣" },
        { label: "男装" },
        { label: "电器" },
        { label: "超市" },
        { label: "鲜菜" },
        { label: "果蔬" }
      ],
      options: {
        activeColor: "#e9232c" //设置选中的颜色
      },
      // 二级路由路径
      subRouteUrl: [
        "/home/hot",
        "/home/dress",
        "/home/shoes",
        "/home/food",
        "/home/wear"
      ]
    };
  },
  methods: {
    handleChange(item, index) {
      // console.log(item, index);
      this.$router.replace(this.subRouteUrl[index]);
    }
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.home {
  background: #f5f5f5;
  width: 100%;
  height: 100%;
}

.fix {
  position: fixed;
  left: 0;
  top: 0;
  z-index: 998;
}
</style>
