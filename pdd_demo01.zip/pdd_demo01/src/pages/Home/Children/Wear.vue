<template>
  <div class="wear">我是内衣板块</div>
</template>
<script>
export default {
  name: " Wear",
  data() {
    return {};
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.wear {
  width: 100%;
  height: 100%;
  background: #cc128d;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>