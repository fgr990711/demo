<template>
  <div class="dress">
    <dress-nav></dress-nav>
  </div>
</template>
<script>
import DressNav from "./DressNav";
export default {
  name: "Dress",
  data() {
    return {};
  },

  components: {
    DressNav
    // HotShopList
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.dress {
  width: 100%;
  height: 100%;
  padding-top: 46px;
  background: #f5f5f5;
}
</style>