<template>
  <div class="dress-nav">
    <div class="dress-nav-content">
      <div class="nav-content-inner">
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-04-13/bd82d50d470ade0369acb36965025acc.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>爸爸装</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2018-09-07/d8e636d80e5a50f9a632668261ac1068.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>衬衫</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2018-09-07/638f461a8a101b44d7837074a8534938.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>牛仔裤</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-04-25/e8d11efc789ac346c06fa6ce157ad743.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>短裤</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2018-10-15/238509a95cfe8bbc15c03a5f5eaba5b0.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>套装</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-02-21/04518348977988e9d6a3301a63a037db.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>夹克外套</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2018-09-07/ab9e44c28a5ef37e5840c6a489e80740.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>休闲裤</span>
        </a>
        <a class="inner-item">
          <img
            src="https://commimg.pddpic.com/oms_img_ng/2020-06-14/dbbf7e73-5fbb-4178-bcfc-98ef5fa129d7.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>春夏新品</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-03-06/104666dbc7c75f4d653dde632b39214f.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>男士内裤</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-03-06/f0e8acf94c6bbeb86b654331c229bc84.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>女士内裤</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2019-10-28/6978cb7692775806712fabaf14439818.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>文胸</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2019-10-28/74a90da1d9a1432c77bc3d60ca9dccd8.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>睡衣家居服</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-03-04/d102108057f9b6dc367a95b4e5826d35.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>品质好货</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2019-10-28/fa162e1ebb3d3aba31f5a5275c34f4a8.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>袜子</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/images/2019-04-09/3e0596c325528896178c9a1dc3db6873.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>吊带/塑身</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-03-12/00e03c84db049e65ca310e325fdd00f9.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
            alt
          />
          <span>童装</span>
        </a>
      </div>
    </div>
    <!--进度条-->
    <div class="dress-nav-bottom">
      <div class="dress-nav-bottom-inner" :style="innerBarStyle"></div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "DressNav",
  data() {
    return {
      // 1. 屏幕的宽度
      screenW:
        window.innerWidth ||
        document.documentElement.clientWidth ||
        document.body.clientWidth,
      // 2. 滚动内容的宽度
      scrollContentW: 720,
      // 3. 滚动条背景的长度
      bgBarW: 100,
      // 4. 滚动条的长度
      barXWidth: 0,
      // 5. 起点
      startX: 0,
      // 6. 记录结束点
      endFlag: 0,
      // 7. 移动的距离
      barMoveWidth: 0
    };
  },
  computed: {
    ...mapState(["homenav"]),

    innerBarStyle() {
      return {
        width: `${this.barXWidth}px`,
        left: `${this.barMoveWidth}px`
      };
    }
  },
  mounted() {
    this.getBottomBarWidth();
    this.bindEvent();
  },
  methods: {
    // 获取滚动条的长度
    getBottomBarWidth() {
      this.barXWidth = this.bgBarW * (this.screenW / this.scrollContentW);
    },
    // 移动端事件监听
    bindEvent() {
      this.$el.addEventListener("touchstart", this.handleTouchStart, false);
      this.$el.addEventListener("touchmove", this.handleTouchMove, false);
      this.$el.addEventListener("touchend", this.handleTouchEnd, false);
    },
    // 开始触摸
    handleTouchStart(event) {
      // console.log(event.touches);
      // 1. 获取第一个触点
      let touch = event.touches[0];
      // 2.求出起始点
      this.startX = Number(touch.pageX);
      // console.log(this.startX);
    },
    // 开始移动
    handleTouchMove() {
      // console.log('开始移动');
      // 1. 获取第一个触点
      let touch = event.touches[0];
      // 2. 求出移动的距离
      let moveWidth = Number(touch.pageX) - this.startX;
      // console.log(moveWidth);
      // 3. 求出滚动条走的距离
      this.barMoveWidth = -(
        (this.bgBarW / this.scrollContentW) * moveWidth -
        this.endFlag
      );

      // 4. 边界值处理
      if (this.barMoveWidth <= 0) {
        // 左边
        this.barMoveWidth = 0;
      } else if (this.barMoveWidth >= this.bgBarW - this.barXWidth) {
        // 右边
        this.barMoveWidth = this.bgBarW - this.barXWidth;
      }
    },
    // 结束触摸
    handleTouchEnd() {
      console.log("结束触摸");
      this.endFlag = this.barMoveWidth;
    }
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.dress-nav {
  width: 100%;
  height: 180px;
  position: relative;
  background-color: #fff;
  padding-bottom: 10px;
}

.dress-nav-content {
  width: 100%;
  overflow-x: scroll;
}

.nav-content-inner {
  width: 720px;
  height: 180px;
  display: flex;
  flex-wrap: wrap;
}

.inner-item {
  width: 90px;
  height: 90px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 14px;
  color: #666666;
}

img {
  width: 50%;
  height: 50%;
  margin-bottom: 5px;
}

.dress-nav-content::-webkit-scrollbar {
  display: none;
}

.dress-nav-bottom {
  width: 100px;
  height: 2px;
  background-color: #ccc;
  position: absolute;
  left: 50%;
  margin-left: -50px;
  bottom: 8px;
}

.dress-nav-bottom-inner {
  position: absolute;
  left: 0;
  height: 100%;
  background-color: #11a9b2;
  width: 0;
}
</style>
