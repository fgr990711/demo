<template>
  <div class="Food">
    <food-nav></food-nav>
  </div>
</template>
<script>
import FoodNav from "./FoodNav";
export default {
  name: "Food",
  data() {
    return {};
  },

  components: {
    FoodNav
    // HotShopList
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.Food {
  width: 100%;
  height: 100%;
  padding-top: 46px;
  background: #f5f5f5;
}
</style>