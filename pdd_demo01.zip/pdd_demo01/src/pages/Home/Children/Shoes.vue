<template>
  <div class="shoes">我是鞋包板块</div>
</template>
<script>
export default {
  name: "Shoes",
  data() {
    return {};
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.shoes {
  width: 100%;
  height: 100%;
  background: #3007c7;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>