<template>
  <div class="shop-container">
    <ul class="shop-list">
      <li class="shop-list-item">
        <img
          src="https://t00img.yangkeduo.com/goods/images/2019-06-05/3458f416-b959-4d6a-aea8-fc82bfef8831.png?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
          alt
          width="100%"
        />
        <h4 class="list-item-title">黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞</h4>
        <div class="list-item-bottom">
          <span class="item-price">￥20.99</span>
          <span class="item-counter">已拼成4222件</span>
          <span class="item-user">
            <img
              src="https://avatar2.pddpic.com/a/b73dc4daaa8b496540f92fa4ba81bb214c787285-1580894443?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
            <img
              src="https://avatar2.pddpic.com/avatar/default/1.png?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
          </span>
          <span class="item-buy">
            <button class>去拼单</button>
          </span>
        </div>
      </li>
      <li class="shop-list-item">
        <img
          src="https://t00img.yangkeduo.com/goods/images/2019-06-05/3458f416-b959-4d6a-aea8-fc82bfef8831.png?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
          alt
          width="100%"
        />
        <h4
          class="list-item-title"
        >黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞</h4>
        <div class="list-item-bottom">
          <span class="item-price">￥20.99</span>
          <span class="item-counter">已拼成4222件</span>
          <span class="item-user">
            <img
              src="https://avatar2.pddpic.com/a/b73dc4daaa8b496540f92fa4ba81bb214c787285-1580894443?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
            <img
              src="https://avatar2.pddpic.com/avatar/default/1.png?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
          </span>
          <span class="item-buy">
            <button class>去拼单</button>
          </span>
        </div>
      </li>
      <li class="shop-list-item">
        <img
          src="https://t00img.yangkeduo.com/goods/images/2019-06-05/3458f416-b959-4d6a-aea8-fc82bfef8831.png?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
          alt
          width="100%"
        />
        <h4
          class="list-item-title"
        >黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞黑胶防晒晴雨两用伞s遮阳伞学生男女防紫外线折叠雨伞三太阳伞</h4>
        <div class="list-item-bottom">
          <span class="item-price">￥20.99</span>
          <span class="item-counter">已拼成4222件</span>
          <span class="item-user">
            <img
              src="https://avatar2.pddpic.com/a/b73dc4daaa8b496540f92fa4ba81bb214c787285-1580894443?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
            <img
              src="https://avatar2.pddpic.com/avatar/default/1.png?imageMogr2/sharpen/50%7CimageView2/2/w/44/q/80/format/webp"
              alt
            />
          </span>
          <span class="item-buy">
            <button>去拼单</button>
          </span>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "HotShopList",
  data() {
    return {};
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.shop-container {
  margin-bottom: 50px;
  background-color: #fff;
}

.shop-list, .shop-list-item {
  margin-bottom: 10px;
  background-color: #fff;
  display: flex;
  flex-direction: column;
}

.list-item-title {
  line-height: 22px;
  width: 94%;
  margin-left: 3%;
  height: 44px;
  overflow: hidden;
}

.list-item-bottom {
  margin: 10px 0;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
}

.item-price {
  color: red;
  font-size: 18px;
  text-align: center;
  font-weight: bolder;
  flex: 1;
}

.item-counter {
  flex: 2;
  font-size: 12px;
  color: #cccccc;
}

.item-user {
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
}

.item-user img {
  width: 45px;
  border-radius: 50%;
}

img:nth-child(2) {
  margin-left: -14px;
}

.item-buy {
  flex: 2;
  font-size: 14px;
}

button {
  width: 80%;
  height: 34px;
  color: #ffffff;
  border: none;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 10px;
  background-color: red;
  border-radius: 10px;
}
</style>