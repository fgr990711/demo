<template>
  <div class="hot-nav">
    <div class="hot-nav-content">
      <div class="nav-content-inner">
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-04-29/798a43c5ae721a5d3dbbcbd5f95488db.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>限时秒杀</span>
        </a>
        <a class="inner-item">
          <img
            src=" https://t00img.yangkeduo.com/goods/2020-03-08/2723bae18ca29e72c195562bfdace6cd.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>断码清场</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/bc63ae848c923737bd799b96d5219f85.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>新衣服</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/b39df4af9b17ba0d063c04da0aea85aa.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>9.9特卖</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/37fe68d866cb25a887beeb74699196b9.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>多多爱消除</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/268178927edd263209650e1c189f5662.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>天天领红包</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/54ece7ca8c54cd8925d631323659e42f.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>省钱月卡</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/54ece7ca8c54cd8925d631323659e42f.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>限时秒杀</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-02-26/f9e3069d2e461cd5f5eb7d77ffce9d9d.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>医药馆</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/0fab520471880b5728fb7150d77f5390.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>充值中心</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-02-24/1ac41ebf88457e29ac4f8b5a01e72f1d.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>现金签到</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/9023c6c212ca7ed147ddfa28c1a13c59.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>多多赚大钱</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-19/617e5544f4e923c683ba601f8d39cd74.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>电器</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/54ece7ca8c54cd8925d631323659e42f.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>限时秒杀</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/54ece7ca8c54cd8925d631323659e42f.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>限时秒杀</span>
        </a>
        <a class="inner-item">
          <img
            src="https://t00img.yangkeduo.com/goods/2020-01-14/54ece7ca8c54cd8925d631323659e42f.png?imageMogr2/sharpen/50%7CimageView2/2/w/117/q/80/format/webp"
            alt
          />
          <span>限时秒杀</span>
        </a>
      </div>
    </div>
    <!--进度条-->
    <div class="hot-nav-bottom">
      <div class="hot-nav-bottom-inner" :style="innerBarStyle"></div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "HotNav",
  data() {
    return {
      // 1. 屏幕的宽度
      screenW:
        window.innerWidth ||
        document.documentElement.clientWidth ||
        document.body.clientWidth,
      // 2. 滚动内容的宽度
      scrollContentW: 720,
      // 3. 滚动条背景的长度
      bgBarW: 100,
      // 4. 滚动条的长度
      barXWidth: 0,
      // 5. 起点
      startX: 0,
      // 6. 记录结束点
      endFlag: 0,
      // 7. 移动的距离
      barMoveWidth: 0
    };
  },
  computed: {
    ...mapState(["homenav"]),

    innerBarStyle() {
      return {
        width: `${this.barXWidth}px`,
        left: `${this.barMoveWidth}px`
      };
    }
  },
  mounted() {
    this.getBottomBarWidth();
    this.bindEvent();
  },
  methods: {
    // 获取滚动条的长度
    getBottomBarWidth() {
      this.barXWidth = this.bgBarW * (this.screenW / this.scrollContentW);
    },
    // 移动端事件监听
    bindEvent() {
      this.$el.addEventListener("touchstart", this.handleTouchStart, false);
      this.$el.addEventListener("touchmove", this.handleTouchMove, false);
      this.$el.addEventListener("touchend", this.handleTouchEnd, false);
    },
    // 开始触摸
    handleTouchStart(event) {
      // console.log(event.touches);
      // 1. 获取第一个触点
      let touch = event.touches[0];
      // 2.求出起始点
      this.startX = Number(touch.pageX);
      // console.log(this.startX);
    },
    // 开始移动
    handleTouchMove() {
      // console.log('开始移动');
      // 1. 获取第一个触点
      let touch = event.touches[0];
      // 2. 求出移动的距离
      let moveWidth = Number(touch.pageX) - this.startX;
      // console.log(moveWidth);
      // 3. 求出滚动条走的距离
      this.barMoveWidth = -(
        (this.bgBarW / this.scrollContentW) * moveWidth -
        this.endFlag
      );

      // 4. 边界值处理
      if (this.barMoveWidth <= 0) {
        // 左边
        this.barMoveWidth = 0;
      } else if (this.barMoveWidth >= this.bgBarW - this.barXWidth) {
        // 右边
        this.barMoveWidth = this.bgBarW - this.barXWidth;
      }
    },
    // 结束触摸
    handleTouchEnd() {
      console.log("结束触摸");
      this.endFlag = this.barMoveWidth;
    }
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
@import 'stylus/hotnav.styl';
</style>
