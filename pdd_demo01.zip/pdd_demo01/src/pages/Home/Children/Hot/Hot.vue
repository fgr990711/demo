<template>
  <div class="hot">
    <!-- 1.轮播图 -->
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s1.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s2.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s3.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s4.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s5.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s6.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s7.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s8.png" alt width="100%" />
        </div>
        <div class="swiper-slide">
          <img src="./../../imgs/sowing/s9.png" alt width="100%" />
        </div>
      </div>
      <!-- 如果需要分页器 -->
      <div class="swiper-pagination"></div>
    </div>
    <!-- 2中间导航 -->
    <hot-nav></hot-nav>
    <!-- 3广告位 -->
    <div class="hot-ad">
      <img
        src="https://commimg.pddpic.com/oms_img_ng/2020-06-18/3404c183-0815-44cd-9d29-1ec89d24267f.gif?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
        alt
        width="100%"
      />
    </div>
    <!--4 商品列表 -->
    <hot-shop-list></hot-shop-list>
  </div>
</template>
<script>
import ajax from "./../../../../api/ajax";
import Swiper from "swiper";
import "swiper/css/swiper.min.css";
import HotNav from "./HotNav";
import HotShopList from "./HotShopList";
export default {
  name: "Hot",
  data() {
    return {};
  },
  mounted() {
    // 创建swiper实例
    new Swiper(".swiper-container", {
      autoplay: true,
      loop: true, // 循环模式选项

      // 如果需要分页器
      pagination: {
        el: ".swiper-pagination"
      }
    });
  },
  components: {
    HotNav,
    HotShopList
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.hot {
  width: 100%;
  height: 100%;
  padding-top: 46px;
  background: #f5f5f5;
}

.hot-ad {
  background-color: #ffffff;
  margin: 7px 0;
  padding: 5px;
}
</style>
