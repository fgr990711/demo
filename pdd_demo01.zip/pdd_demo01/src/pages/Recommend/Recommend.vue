<template>
  <div class="recommend-container">
    <shop-list tag="li"></shop-list>
  </div>
</template>
<script>
import {} from "vuex";
import ShopList from "./../../components/ShopList/ShopList";
export default {
  name: "Recommend",
  components: {
    ShopList
  }
  // mounted() {
  //   this.$route.dispatch("reqRecommendShopList");
  // }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.recommend-container {
  background: #f5f5f5;
  width: 100%;
  height: 100%;
}

.recommend {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  background: #f5f5f5;
  margin-bottom: 50px;
}
</style>
