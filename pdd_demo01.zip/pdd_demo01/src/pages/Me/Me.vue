<template>
  <div class="me">个人中心</div>
</template>
<script>
export default {
  name: "Me"
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.me {
  background: yellow;
  width: 100%;
  height: 100%;
}
</style>
