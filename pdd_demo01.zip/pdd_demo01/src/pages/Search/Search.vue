<template>
  <div class="search">
    <!-- 搜索导航栏 -->
    <search-nav></search-nav>

    <div class="shop">
      <!-- 左边 -->
      <div class="menu-wrapper" ref="wrapper">
        <ul>
          <li class="menu-item current">
            <span>女装</span>
          </li>
          <li class="menu-item">
            <span>服饰</span>
          </li>
          <li class="menu-item">
            <span>男装</span>
          </li>
          <li class="menu-item">
            <span>食品</span>
          </li>
          <li class="menu-item">
            <span>饮料</span>
          </li>
          <li class="menu-item">
            <span>手机</span>
          </li>
          <li class="menu-item">
            <span>电器</span>
          </li>
          <li class="menu-item">
            <span>五金</span>
          </li>
          <li class="menu-item">
            <span>塑料</span>
          </li>
          <li class="menu-item">
            <span>环保</span>
          </li>
          <li class="menu-item">
            <span>科学</span>
          </li>
          <li class="menu-item">
            <span>智能</span>
          </li>
          <li class="menu-item">
            <span>儿童</span>
          </li>
        </ul>
      </div>
      <!-- 右边 -->
      <div class="shop-wrapper">
        <ul>
          <li class="shops-li">
            <div class="shops-title">
              <h4>女装</h4>
              <a href>查看更多</a>
            </div>
            <ul class="shops-items">
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
            </ul>
          </li>
        </ul>
        <ul>
          <li class="shops-li">
            <div class="shops-title">
              <h4>女装</h4>
              <a href>查看更多</a>
            </div>
            <ul class="shops-items">
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
              <li class="shops-items-li">
                <img
                  src="https://t00img.yangkeduo.com/goods/2020-04-20/204c9e69a523b2fd6d4a6c7295dbb8e2.png?imageMogr2/sharpen/50%7CimageView2/2/w/1300/q/80/format/webp"
                  alt
                />
                <span>女装</span>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import SearchNav from "./Children/SearchNav";

import BScroll from "better-scroll";
export default {
  name: "Search",
  components: {
    SearchNav
  },
  mounted() {
    this.$nextTick(() => {
      this.scroll = new Bscroll(this.$refs.wrapper, {});
    });
  }
};
</script>

<style scoped lang="stylus" ref="stylesheet/stylus">
.search {
  background: #fff;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.shop {
  display: flex;
  position: absolute;
  top: 60px;
  bottom: 50px;
  width: 100%;
  overflow: hidden;
}

.menu-wrapper {
  background-color: #f1f0f0;
  width: 80px;
  flex: 0 0 80px;
}

.menu-item {
  width: 100%;
  height: 60px;
  background-color: #fafafa;
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: lighter;
  color: #666;
  position: relative;
}

.current {
  color: #e02e24;
}

.current::before {
  content: '';
  background-color: #e02e24;
  width: 4px;
  height: 30px;
  position: absolute;
  left: 0;
}

.shop-wrapper {
  flex: 1;
  background-color: #fff;
}

.shops-title {
  display: flex;
  flex-direction: row;
  padding: 2 10px;
  height: 44px;
  align-items: center;
  justify-content: space-around;
  color: #999;
}

a {
  color: #999;
  text-decoration: none;
  font-weight: lighter;
}

.shops-items {
  display: flex;
  flex-wrap: wrap;
}

.shops-items-li {
  display: flex;
  flex-direction: column;
  width: 33.3%;
  height: 90px;
  justify-content: center;
  align-items: center;
  font-weight: lighter;
  font-size: 14px;
}

.shops-items-li img {
  width: 60%;
  height: 60%;
  margin-bottom: 5px;
}
</style>
