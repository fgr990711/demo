<template>
  <div class="chat">聊天</div>
</template>
<script>
export default {
  name: "Chat"
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.chat {
  background: blue;
  width: 100%;
  height: 100%;
}
</style>
