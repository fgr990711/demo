<template>
  <ul class="recommend">
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>

    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
    <li class="recommend-item">
      <img
        src="https://t00img.yangkeduo.com/goods/images/2020-05-14/3e351c6a1e02741131b63ca3a6cb4bed.jpeg?imageMogr2/sharpen/50%7CimageView2/2/w/312/q/80/format/webp"
        alt
        width="100%"
      />
      <h4 class="item-title">豆腐干华盛顿分公司的反馈是大法官上的加法开始的</h4>
      <div class="item-bottom">
        <span class="item-price">￥20.9</span>
        <span class="item-sales">已42件</span>
        <button class="item-btn">找相关</button>
      </div>
    </li>
  </ul>
</template>
<script>
export default {
  name: "ShopList",
  props: {
    item: Object
  }
};
</script>
<style scoped lang="stylus" ref="stylesheet/stylus">
.recommend-item:nth-child(2n-1) {
  margin-right: 1%;
}

.recommend-item {
  width: 49.5%;
  background: #ffffff;
  padding-bottom: 15px;
  margin-bottom: 15px;
}

.item-title {
  line-height: 20px;
  font-size: 13px;
  font-weight: lighter;
  height: 20px;
  margin: 5px 0;
  overflow: hidden;
  padding: 0 5px;
}

.item-bottom {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 0 6px;
}

.item-price {
  flex: 2;
  color: red;
  font-weight: bolder;
  font-size: 12px;
}

.item-sales {
  flex: 4;
  font-size: 10px;
  color: #666;
}

.item-btn {
  flex: 2;
  border: 1px solid red;
  height: 26px;
  border-radius: 5px;
  background-color: transparent;
  color: red;
  font-size: 10px;
}
</style>