export const HOME_CASUAL = 'home_casual'; //首页轮播
