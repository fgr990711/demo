export default {
  // 首页轮播图
  homecasual: [],
  searchgoods: []
}
