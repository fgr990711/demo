import {
  getHomeCasual
} from ' ../api';
import {
  HOME_CASUAl
} from './mutation-types';
export default {
  // 获取轮播图
  async reqHomeCasual({
    commit
  }) {
    const result = await getHomeCasual();
    commit(HOME_CASUAl, {
      homecasual: result.message.data
    })
  }
}
