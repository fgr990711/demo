import {
  HOME_CASUAl
} from './mutation-types';


export default {
  [HOME_CASUAl](state, {
    homecasual
  }) {
    state.homecasual = homecasual;
  }
}
