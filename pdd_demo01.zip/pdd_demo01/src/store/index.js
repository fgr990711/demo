// import Vue from "vue";
// import Vuex from "vuex";
// import state from "./state";
// import mutation from "./mutation";
// import actions from "./actions";
// import getters from "./getters";
// //1.使用vuex
// Vuex.use(Vuex);
// //2.对外输出vuex的store对象
// export default new Vuex.Store({
//   state,
//   mutation,
//   actions,
//   getters,

// })
