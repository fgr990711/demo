// 1引入对应模块
// 一级路由
import Vue from 'vue'
import Router from 'vue-router'
import Home from './../pages/Home/Home';
import Chat from './../pages/Chat/Chat';
import Me from './../pages/Me/Me';
import Search from './../pages/Search/Search';
import Recommend from './../pages/Recommend/Recommend';
// 二级路由板块
import Hot from './../pages/Home/Children/Hot/Hot';
import Dress from './../pages/Home/Children/Dress/Dress';
import Shoes from './../pages/Home/Children/Shoes';
import Food from './../pages/Home/Children/Food/Food';
import Wear from './../pages/Home/Children/Wear';



const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
// 2声明使用
Vue.use(Router)

// 3输出路由对象
export default new Router({
  routes: [{
      path: '/',
      redirect: "/home"
    },
    {
      path: '/home',
      component: Home,
      children: [{
          path: '/home',
          redirect: "/home/hot"
        },
        { //热门板块
          path: 'hot',
          component: Hot
        },
        { //食品板块
          path: 'food',
          component: Food
        },
        { //服饰板块
          path: 'dress',
          component: Dress
        },
        { //鞋包板块
          path: 'shoes',
          component: Shoes
        },
        { //内衣板块
          path: 'wear',
          component: Wear
        },

      ]
    },
    {
      path: '/me',
      component: Me
    },
    {
      path: '/search',
      component: Search
    },
    {
      path: '/recommend',
      component: Recommend
    },
    {
      path: '/chat',
      component: Chat
    },
  ]

})
